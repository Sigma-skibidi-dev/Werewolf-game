import flet as ft
import random as r
import time as t

def main(page: ft.Page):
    randomlist = ['werewolf', 'civilian', 'civilian', 'civilian']
    roles = {}
    playerlist = []
    gamestate = 'day'
    number = 0
     

    def playeradder():
        length = len(playerlist)
        for i in range(length):
            player_text = ft.Text(value=playerlist[i])
            column.controls.append(player_text) 

    def add_vote_buttons():
        for i in range(len(playerlist)):
            vote_button = ft.ElevatedButton(
                text=('kill'), 
                on_click=lambda e, index=i: addvote(index)  
            )
            row = ft.Row(controls=[vote_button])
            columnv.controls.append(row)

    def addvote(index):
        if index < len(column.controls): 
            if howmanycanikill.value != 0:
                player_text_control = column.controls[index]
                deleter = roles[player_text_control.value]
                randomlist.remove(deleter)
                del roles[player_text_control.value] 
                player_text_control.value = ''
                howmanycanikill.value -= 1
                page.update()
                print(roles)
        else:
            errortextvalue.value = "you've killed all the people you can"
            page.update()

    def playeramount(e):
        try:
            playernumb.value = int(playernumb.value)
            if playernumb.value >= 4:
                rolegenerator = playernumb.value - 4
                mylifeisfullofpain = playernumb.value

                fiver = rolegenerator // 5
                
                
                mylifeisfullofpain -= fiver
                mylifeisfullofpain -= 4
                
                randomlist.extend(['civilian'] * mylifeisfullofpain)
                
                if fiver > 0:
                    for i in range(fiver):
                        randomlist.append('werewolf')


                        
                errortextvalue.value = ''
                r.shuffle(randomlist) 

                page.remove(playernumb, playerregistry, errortextvalue)
                page.add(addPlayerButton, playerNametf, errortextvalue, rolerevealer)
                page.update()
            elif playernumb.value < 4:
                errortextvalue.value = "please try again when you get friends, there aren't enough players, loser"
                page.update()

        except ValueError:
            errortextvalue.value = 'please put in a number'
            page.update()
        
    def newplayer(e):
        pr = int(playerregistered.value)
        p = int(progress.value)
        bob = len(randomlist)
        
        if p < bob:
                if playerNametf.value != '':
                    chooser = randomlist[p]
                    
                    roles[playerNametf.value] = chooser
                    
                    rolestorer.options.append(ft.dropdown.Option(playerNametf.value))
                    playerlist.append(playerNametf.value)
                    page.add(ft.Text(value=playerNametf.value))

                    player_name_text = ft.Text(value=playerNametf.value)
                    column.controls.append(player_name_text)

                    playerNametf.value = ""
                    playerNametf.focus()

                    playerregistered.value = 1 + pr
                    progress.value = 1 + p
                    page.update() 

                else:
                    errortextvalue.value = 'please enter a name'
                    page.update()  
            

        else:
                errortextvalue.value = 'you cannot add more people'
                playerNametf.disabled = True
                page.update()
                t.sleep(100)  
                page.clean()
                easter = ft.Video(playlist=[ft.VideoMedia("egg.mp4")],
                                expand=True,
                                autoplay=True,  
                                height=400, width=1200)  
                page.add(easter)
                page.update()
                t.sleep(10)
                page.remove(easter)
                errortextvalue.value = 'thanks for finding this easter egg'
                page.add(starter, errortextvalue)
                page.update()
                errortextvalue.value = ''
        

    def revealsetup(e):
        page.clean()
        errortextvalue.value = 'for this to work, everyone but the person checking their own role must close their eyes'
        page.add(rolestorer, errortextvalue, starter, clearrolebutton)
        page.update()

    def reveal(e):
        print(roles)
        print(rolestorer.value)
        errortextvalue.value = f"{rolestorer.value} you are a {roles[rolestorer.value]}"
        page.update()

    def cleartext(e):
        errortextvalue.value = ''
        page.update()

    
    def startgame(e):
        errortextvalue.value = 'civilians, wait until the rooster sings before waking up, today you cannot kill anyone'
        pr = int(playerregistered.value)
        bob = len(randomlist)
        if pr == bob:
            page.clean()
            
            # Clear existing controls in both columns to ensure only one set is displayed
            column.controls.clear()
            columnv.controls.clear()
            
            playeradder()  # Add player names to the column
            add_vote_buttons()  # Add vote buttons for those players
            
            row = ft.Row(controls=[column, columnv])  
            page.add(row,errortextvalue, nextturn)
            page.update()
    
    def sleep(e):
        page.remove(nextturn)
        print(roles)
        werewolfcount = randomlist.count('werewolf')
        civiliancount = len(roles) - werewolfcount
        howmanycanikill.value =  randomlist.count('werewolf')
        errortextvalue.value = 'please close your eyes, werewolfs, wait until the auuuuuuuuu before reopening them'
        page.update()
        t.sleep(6)
        audio1 = ft.Audio(
        src="auuu.mp3", autoplay=True)
        page.overlay.append(audio1)

        if werewolfcount == 0:
            page.clean()
            cw = ft.Image(src="win.jpg")
            audio1 = ft.Audio(
            src="celeration.mp3", autoplay=True)
            page.overlay.append(audio1)
            page.add(cw)
            page.update()

        elif werewolfcount >= civiliancount:
            page.clean()
            errortextvalue.value = 'werewolves win'
            row = ft.Row(controls=[errortextvalue]) 
            for i in range(werewolfcount):
                ww = ft.Video(playlist=[ft.VideoMedia("win.mp4")], autoplay=True, muted=True, height=640, width=360)
                row = ft.Row()
                row.controls.append(ww) 
            audio1 = ft.Audio(
            src="werewolfwin.mp3", autoplay=True)
            page.overlay.append(audio1)
            page.add(row, errortextvalue)
            page.update()
        else:
            errortextvalue.value = 'please choose a person to kill'
            page.add(nextturn1)
            page.update()

    def wakeup(e):
        howmanycanikill.value = 1
        print(howmanycanikill)
        errortextvalue.value = 'werewolves, close your eyes quick'
        page.update()
        t.sleep(5)
        audio1 = ft.Audio(
        src="cockadoodledo.mp3", autoplay=True)
        page.overlay.append(audio1)
        errortextvalue.value = 'please wake up, decide who is the werewolf'
        page.remove(nextturn1)
        page.add(nextturn)
        page.update()

        




    

    playerregistered = ft.Text(value='0')
    progress = ft.Text(value='0')

    errortextvalue = ft.Text(value='')
    playernumb = ft.TextField(hint_text='how many players will play? (minimum is 4)', on_submit=playeramount)
    playerregistry = ft.ElevatedButton(text='submit', on_click=playeramount)

    addPlayerButton = ft.ElevatedButton(text="Add player", on_click=newplayer)
    playerNametf = ft.TextField(hint_text="Player Name: ", on_submit=newplayer)
    rolerevealer = ft.ElevatedButton(text='start game', on_click=revealsetup)

    rolestorer = ft.Dropdown(hint_text='Roles', on_change=reveal, options = [])
    clearrolebutton = ft.ElevatedButton(text='clear text', on_click=cleartext)

    starter = ft.ElevatedButton(text='start game', on_click=startgame)

    column = ft.Column()
    columnv = ft.Column()

    nextturn = ft.ElevatedButton(text='go to sleep', on_click=sleep)
    nextturn1 = ft.ElevatedButton(text='wakeup', on_click=wakeup)
    howmanycanikill = ft.Text(value=0)

    page.add(playernumb, playerregistry, errortextvalue)

ft.app(target=main)
#https://www.perplexity.ai/search/def-playeradder-length-len-pla-MVy0098PQdCTG97G6xEaMw