import flet as ft
import random

def main(page: ft.Page):
    randomlist = [
        "apple", "banana", "cherry", "date", "elderberry", "fig", "grape",
        "honeydew", "kiwi", "lemon", "mango", "nectarine", "orange",
        "papaya", "quince", "raspberry", "strawberry", "tangerine",
        "ugli fruit", "vanilla", "watermelon", "xigua", "yam",
        "zucchini", "avocado", "blueberry", "cantaloupe", "dragonfruit",
        "eggplant", "figs", "grapefruit", "huckleberry", "jalapeño",
        "kumquat", "lime", "mushroom", "nectarines", "olive",
        "peach", "pear", "plum", "quinoa", "radish",
        "spinach", "tomato", "ugli fruit", "vanilla bean",
        "wasabi", "xanadu fruit", "yarrow flower", 
        "zest", "basil", "cinnamon", "dill",
        "coriander", "thyme", "sage", 
        "turmeric", "ginger", "pepper",
        "cabbage", "carrot", 
        "celery",  "broccoli",
        "cauliflower","kale","lettuce","onion","garlic",
        "beetroot","pumpkin","squash","turnip","radicchio",
        "arugula","endive","fennel","bok choy","asparagus",
        "artichoke","brussels sprouts","chard","collard greens",
        "mustard greens","watercress","seaweed","nori",
        "kelp","spirulina","algae","quinoa flakes",
        "chia seeds","flax seeds","hemp seeds",
        "pumpkin seeds","sunflower seeds","sesame seeds",
        "walnuts","almonds ","cashews",
        "Pneumonoultramicroscopicsilicovolcanoconiosis"
        ]
    random.shuffle(randomlist)
    bob = len(randomlist)
    randomlist.append("You Won")
    
    thing = 0

    def chooseWord():
        display.value = randomlist[progress.data]
    def checker(e):   
        accnumb = float(bob/100)
        if display.value == 101:
            inp.disabled(True)
        else:
            if inp.value == display.value:
                correct.value = "correct"
                correct.color = ft.colors.GREEN
                accuracy.value = accuracy.value
                audio1 = ft.Audio(
                src="yay.mp3", autoplay=True
                )
                page.overlay.append(audio1)
                inp.value = ""
                progress.data = progress.data + 1
                progress.value = f"{progress.data}/{bob}"
            
            else:
                correct.value = "incorrect"
                correct.color = ft.colors.RED
                accuracy.value = accuracy.value - accnumb
                audio1 = ft.Audio(
                src="wrong.mp3", autoplay=True
                )
                page.overlay.append(audio1)
                inp.value = ""
                progress.data+=1
                progress.value = f"{progress.data}/{bob}"
            correct.update()
            chooseWord()
        page.update()
        

    inp = ft.TextField(label="type here", on_submit=checker)
    display = ft.Text(value=randomlist[0])
    accuracy = ft.Text(value=100)
    progress = ft.Text(value='', data=0)
    correct = ft.Text(value="")
    
    page.add(inp,display,accuracy,progress,correct)
ft.app(target=main)

    #https://flet.dev/docs/controls/audio/

